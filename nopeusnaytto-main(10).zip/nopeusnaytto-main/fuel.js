console.log("Fuel.js on poistettu käytöstä, toiminnot on siirretty ui.js ja history.js tiedostoihin.");
